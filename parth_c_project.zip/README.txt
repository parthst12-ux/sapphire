
Parth C Project
---------------
Simple password checking project in C.

Compile:
    gcc password_checker.c password.c -o ParthProject

Run:
    ./ParthProject   (Linux/Mac)
    ParthProject.exe (Windows)

By Parth Singh
